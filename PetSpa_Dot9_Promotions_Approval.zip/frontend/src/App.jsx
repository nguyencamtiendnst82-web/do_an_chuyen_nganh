import { BrowserRouter, Navigate, Outlet, Route, Routes } from 'react-router-dom'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'

// Layouts
import PublicLayout from './layouts/PublicLayout'
import CustomerLayout from './layouts/CustomerLayout'
import StaffLayout from './layouts/StaffLayout'
import AdminLayout from './layouts/AdminLayout'

// Pages – Auth
import LoginPage from './pages/auth/LoginPage'
import RegisterPage from './pages/auth/RegisterPage'
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage'
import ResetPasswordPage from './pages/auth/ResetPasswordPage'
import ProfilePage from './pages/auth/ProfilePage'

// Pages – Public
import HomePage from './pages/HomePage'

// Pages – Customer
import PetsPage from './pages/customer/PetsPage'
import ServiceCatalogPage from './pages/customer/ServiceCatalogPage'
import BookingPage from './pages/customer/BookingPage'
import MyAppointmentsPage from './pages/customer/MyAppointmentsPage'
import CareBookPage from './pages/customer/CareBookPage'

// Pages – Staff
import StaffDashboard from './pages/staff/StaffDashboard'
import PetsManagePage from './pages/staff/PetsManagePage'
import MyShiftsPage from './pages/staff/MyShiftsPage'
import AppointmentsManagePage from './pages/staff/AppointmentsManagePage'
import IncidentsPage from './pages/staff/IncidentsPage'
import StaffKanbanPage from './pages/staff/StaffKanbanPage'

// Pages – Admin
import AdminDashboard from './pages/admin/AdminDashboard'
import ServicesAdminPage from './pages/admin/ServicesAdminPage'
import PromotionsPage from './pages/admin/PromotionsPage'
import UsersManagePage from './pages/admin/UsersManagePage'
import ShiftsManagePage from './pages/admin/ShiftsManagePage'
import ReportsPage from './pages/admin/ReportsPage'
import LogsPage from './pages/admin/LogsPage'

// Pages – Public & Shared
import EmployeesPage from './pages/public/EmployeesPage'

// Pages – 404
import NotFoundPage from './pages/NotFoundPage'

/**
 * ProfileRoute: Route /profile hiển thị trong layout tương ứng với role hiện tại
 */
const ProfileRoute = () => {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />

  const layoutMap = {
    admin: <AdminLayout />,
    staff: <StaffLayout />,
    customer: <CustomerLayout />,
  }
  const Layout = () => layoutMap[user.role_name] || <CustomerLayout />

  return (
    <Layout>
      <Outlet />
    </Layout>
  )
}

/**
 * EmployeesLayout: trang /employees ai cũng xem được, nhưng khung giao diện theo người xem:
 * khách hàng đã đăng nhập → CustomerLayout (có đủ menu điều hướng); còn lại → PublicLayout.
 */
const EmployeesLayout = () => {
  const { user } = useAuth()
  return user?.role_name === 'customer' ? <CustomerLayout /> : <PublicLayout />
}

/**
 * HomeRoute: quản trị viên (chủ cửa hàng) không dùng trang chủ công khai → chuyển thẳng về /admin
 */
const HomeRoute = () => {
  const { user } = useAuth()
  if (user?.role_name === 'admin') return <Navigate to="/admin" replace />
  return <HomePage />
}

const App = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          {/* ── Public routes (không cần đăng nhập) ─────────────────── */}
          <Route element={<PublicLayout />}>
            <Route path="/" element={<HomeRoute />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/reset-password" element={<ResetPasswordPage />} />
          </Route>

          <Route element={<EmployeesLayout />}>
            <Route path="/employees" element={<EmployeesPage />} />
          </Route>

          {/* ── /profile: cho phép cả 3 role, layout theo role ────────── */}
          <Route element={<ProtectedRoute allowedRoles={['customer', 'staff', 'admin']} />}>
            <Route path="/profile" element={<ProfileRoute />}>
              <Route index element={<ProfilePage />} />
            </Route>
          </Route>

          {/* ── Customer routes ────────────────────────────────────────── */}
          <Route element={<ProtectedRoute allowedRoles={['customer']} />}>
            <Route element={<CustomerLayout />}>
              <Route path="/pets" element={<PetsPage />} />
              <Route path="/booking" element={<BookingPage />} />
              <Route path="/appointments" element={<MyAppointmentsPage />} />
              <Route path="/care-book" element={<CareBookPage />} />
              <Route path="/services" element={<ServiceCatalogPage />} />
            </Route>
          </Route>

          {/* ── Staff routes ───────────────────────────────────────────── */}
          <Route element={<ProtectedRoute allowedRoles={['staff']} />}>
            <Route element={<StaffLayout />}>
              <Route path="/staff" element={<StaffDashboard />} />
              <Route path="/staff/today" element={<StaffKanbanPage />} />
              <Route path="/staff/appointments" element={<AppointmentsManagePage />} />
              <Route path="/staff/incidents" element={<IncidentsPage />} />
              <Route path="/staff/pets" element={<PetsManagePage />} />
              <Route path="/staff/shifts" element={<MyShiftsPage />} />
              <Route path="/staff/services" element={<ServiceCatalogPage />} />
            </Route>
          </Route>

          {/* ── Admin routes ───────────────────────────────────────────── */}
          <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
            <Route element={<AdminLayout />}>
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/reports" element={<ReportsPage />} />
              <Route path="/admin/logs" element={<LogsPage />} />
              <Route path="/admin/users" element={<UsersManagePage />} />
              <Route path="/admin/appointments" element={<AppointmentsManagePage />} />
              <Route path="/admin/incidents" element={<IncidentsPage />} />
              <Route path="/admin/shifts" element={<ShiftsManagePage />} />
              <Route path="/admin/services" element={<ServicesAdminPage />} />
              <Route path="/admin/promotions" element={<PromotionsPage />} />
              <Route path="/admin/pets" element={<PetsManagePage />} />
            </Route>
          </Route>

          {/* ── 404 ────────────────────────────────────────────────────── */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  )
}

export default App