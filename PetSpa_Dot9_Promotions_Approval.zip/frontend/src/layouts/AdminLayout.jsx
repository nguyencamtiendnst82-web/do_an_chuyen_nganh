import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import NotificationBell from '../components/NotificationBell'

/**
 * AdminLayout: Sidebar thu gọn được trên mobile cho quản trị viên
 */
const AdminLayout = () => {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleLogout = async () => {
    await logout()
    navigate('/login')
  }

  const navLinks = [
    { to: '/admin', label: 'Dashboard', icon: '📊', exact: true },
    { to: '/admin/reports', label: 'Báo cáo doanh thu', icon: '📈' },
    { to: '/admin/logs', label: 'Nhật ký hệ thống', icon: '📋' },
    { to: '/admin/users', label: 'Nhân viên & khách hàng', icon: '👥' },
    { to: '/admin/appointments', label: 'Lịch hẹn', icon: '📅' },
    { to: '/admin/incidents', label: 'Sự cố', icon: '⚠️' },
    { to: '/admin/shifts', label: 'Ca làm việc', icon: '⏰' },
    { to: '/admin/services', label: 'Dịch vụ', icon: '✂️' },
    { to: '/admin/promotions', label: 'Khuyến mãi', icon: '🏷️' },
    { to: '/admin/pets', label: 'Hồ sơ thú cưng', icon: '🐶' },
    { to: '/profile', label: 'Hồ sơ cá nhân', icon: '👤' },
  ]

  const Sidebar = ({ mobile = false }) => (
    <aside
      className={`${mobile
          ? 'fixed inset-0 z-40 flex'
          : 'hidden md:flex flex-col w-64 shrink-0 bg-white border-r border-gray-200 sticky top-0 h-screen self-start overflow-y-auto'
        }`}
    >
      {mobile && (
        <div className="fixed inset-0 bg-black/40" onClick={() => setSidebarOpen(false)} />
      )}
      <div className={`${mobile ? 'relative z-50 w-64 bg-white min-h-screen flex flex-col' : 'flex flex-col w-full'}`}>
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-gray-100">
          <span className="text-2xl mr-2">🐾</span>
          <span className="font-bold text-gray-800">Pet Spa</span>
          <span className="ml-2 text-xs text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">Admin</span>
        </div>

        {/* User info */}
        <div className="px-4 py-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-bold text-sm overflow-hidden shrink-0">
  {user?.avatar_url
    ? <img src={user.avatar_url} alt="Ảnh đại diện" className="w-9 h-9 rounded-full object-cover" />
    : user?.full_name?.[0]?.toUpperCase() || 'A'
  }
</div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-800 truncate">{user?.full_name}</p>
              <p className="text-xs text-purple-600 truncate">Quản trị viên</p>
            </div>
            <NotificationBell tone="blue" />
          </div>
        </div>

        {/* Nav links */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navLinks.map(({ to, label, icon, exact }) => (
            <NavLink
              key={to}
              to={to}
              end={exact}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${isActive
                  ? 'bg-purple-50 text-purple-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`
              }
            >
              <span>{icon}</span>
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        {/* Logout */}
        <div className="px-3 py-4 border-t border-gray-100">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
          >
            <span>🚪</span>
            <span>Đăng xuất</span>
          </button>
        </div>
      </div>
    </aside>
  )

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Desktop sidebar */}
      <Sidebar />

      {/* Mobile sidebar */}
      {sidebarOpen && <Sidebar mobile />}

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Mobile header */}
        <header className="md:hidden bg-white border-b border-gray-200 h-14 flex items-center px-4 gap-4">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1.5 text-gray-500 hover:text-gray-900"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <span className="font-semibold text-gray-800">🐾 Pet Spa – Admin</span>
        </header>

        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

export default AdminLayout
