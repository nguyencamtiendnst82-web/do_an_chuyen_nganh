import { useCallback, useEffect, useState } from 'react'
import axiosClient from '../api/axiosClient'
import Modal from './Modal'
import StatusBadge from './StatusBadge'
import PetAvatar from './PetAvatar'
import CareRecordCard from './CareRecordCard'
import { useToast } from './Feedback'
import { useAuth } from '../contexts/AuthContext'
import { formatVND, errorMessage, SPECIES_LABEL, GENDER_LABEL, formatAge } from '../utils/format'
import { formatDateLong, hm } from '../utils/appointment'
import { PAYMENT_STATUS_LABEL, PAYMENT_STATUS_STYLE } from '../utils/invoice'
import CreateInvoiceModal from './CreateInvoiceModal'
import InvoiceDetailModal from './InvoiceDetailModal'

const Row = ({ label, children }) => (
  <div className="flex justify-between gap-4 py-2 text-sm">
    <dt className="text-gray-500 shrink-0">{label}</dt>
    <dd className="text-gray-900 text-right">{children}</dd>
  </div>
)

/** Thông tin thú cưng (chỉ đọc) cho nhân viên/admin: tải từ GET /pets/:id */
const PetInfoBlock = ({ petId }) => {
  const [pet, setPet] = useState(null)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    let alive = true
    axiosClient.get(`/pets/${petId}`)
      .then((res) => { if (alive) setPet(res.data.data.pet) })
      .catch(() => { if (alive) setFailed(true) })
    return () => { alive = false }
  }, [petId])

  if (failed) return <p className="text-xs text-gray-500">Không tải được thông tin thú cưng.</p>
  if (!pet) return <div className="h-16 bg-gray-100 rounded-lg animate-pulse" aria-busy="true" />

  const info = [
    ['Loài / giống', `${SPECIES_LABEL[pet.species] || ''}${pet.breed ? ` · ${pet.breed}` : ''}`],
    ['Giới tính', GENDER_LABEL[pet.gender] || 'Chưa rõ'],
    ['Tuổi', pet.age_months != null ? formatAge(pet.age_months) : 'Chưa rõ'],
    ['Cân nặng', pet.weight_kg != null ? `${pet.weight_kg} kg` : 'Chưa rõ'],
  ]
  return (
    <div className="rounded-xl border border-gray-200 p-3 space-y-2">
      <div className="flex items-center gap-3">
        <PetAvatar pet={pet} size="w-12 h-12" text="text-xl" />
        <div className="min-w-0">
          <p className="font-medium text-gray-900 truncate">{pet.name}</p>
          <p className="text-xs text-gray-500">Chủ nuôi: {pet.owner_name}{pet.owner_phone ? ` · ${pet.owner_phone}` : ''}</p>
        </div>
      </div>
      <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
        {info.map(([k, v]) => (
          <div key={k} className="flex justify-between gap-2"><dt className="text-gray-500">{k}</dt><dd className="text-gray-900 text-right">{v}</dd></div>
        ))}
      </dl>
      <div>
        <p className="text-xs font-medium text-gray-600">Lưu ý sức khỏe / tính cách</p>
        <p className="text-sm text-gray-700 bg-amber-50 rounded-lg px-3 py-2 whitespace-pre-wrap">
          {pet.special_notes || 'Không có lưu ý.'}
        </p>
      </div>
      <div>
        <p className="text-xs font-medium text-red-700">Dị ứng</p>
        <p className="text-sm text-gray-700 bg-red-50 rounded-lg px-3 py-2 whitespace-pre-wrap">{pet.allergies || 'Không ghi nhận.'}</p>
      </div>
      <div>
        <p className="text-xs font-medium text-gray-600">Tiêm phòng / tẩy giun</p>
        <p className="text-sm text-gray-700 bg-gray-50 rounded-lg px-3 py-2 whitespace-pre-wrap">{pet.vaccination_notes || 'Chưa có ghi chú.'}</p>
      </div>
    </div>
  )
}

/**
 * AppointmentDetailModal: chi tiết một lịch hẹn (dịch vụ, giá lúc đặt, nhân viên, ghi chú).
 * staffMode = true: hiện thêm SĐT khách và ô ghi chú nội bộ (staff_notes) để nhân viên sửa.
 * renderActions(appointment, reload): vùng nút thao tác do trang cha truyền vào.
 */
const AppointmentDetailModal = ({ id, onClose, staffMode = false, renderActions, onChanged }) => {
  const toast = useToast()
  const { user } = useAuth()
  const [apt, setApt] = useState(null)
  const [error, setError] = useState('')
  const [notes, setNotes] = useState('')
  const [savingNotes, setSavingNotes] = useState(false)
  const [showInvoiceModal, setShowInvoiceModal] = useState(false)
  const [showCreateInvoiceModal, setShowCreateInvoiceModal] = useState(false)
  const isStaffUser = user?.role_name === 'staff'
  // Chỉ nhân viên phụ trách được sửa ghi chú nội bộ; admin chỉ xem
  const canEditNotes = !apt || (isStaffUser && apt.employee_user_id === user?.id)

  const load = useCallback(async () => {
    try {
      const res = await axiosClient.get(`/appointments/${id}`)
      setApt(res.data.data)
      setNotes(res.data.data.staff_notes || '')
    } catch (err) {
      setError(errorMessage(err, 'Không tải được chi tiết lịch hẹn.'))
    }
  }, [id])

  useEffect(() => { load() }, [load])

  const reload = async () => { await load(); onChanged?.() }

  const saveNotes = async () => {
    setSavingNotes(true)
    try {
      // Gửi lại đúng trạng thái hiện tại: server chỉ cập nhật ghi chú
      await axiosClient.patch(`/appointments/${apt.id}/status`, { status: apt.status, staff_notes: notes.trim() })
      toast.success('Đã lưu ghi chú nội bộ.')
      await reload()
    } catch (err) {
      toast.error(errorMessage(err, 'Không lưu được ghi chú.'))
    } finally {
      setSavingNotes(false)
    }
  }

  const total = apt ? apt.details.reduce((s, d) => s + d.price_at_booking, 0) : 0

  return (
    <Modal title="Chi tiết lịch hẹn" onClose={onClose}>
      {error && <p className="text-sm text-red-600" role="alert">{error}</p>}
      {!apt && !error && <div className="space-y-3" aria-busy="true">{[1, 2, 3, 4].map((i) => <div key={i} className="h-5 bg-gray-200 rounded animate-pulse" />)}</div>}
      {apt && (
        <div className="space-y-5">
          <div className="flex items-center gap-3">
            <PetAvatar pet={{ name: apt.pet_name, species: apt.pet_species, avatar_url: apt.pet_avatar }} />
            <div className="min-w-0 flex-1">
              <p className="font-semibold text-gray-900 truncate">{apt.pet_name}</p>
              <p className="text-xs text-gray-500">{SPECIES_LABEL[apt.pet_species] || ''}{apt.pet_breed ? ` · ${apt.pet_breed}` : ''}</p>
            </div>
            <StatusBadge status={apt.status} />
          </div>

          <dl className="divide-y divide-gray-100 border-y border-gray-100">
            <Row label="Mã lịch hẹn"><span className="font-mono">{apt.appointment_code}</span></Row>
            <Row label="Ngày">{formatDateLong(apt.appointment_date)}</Row>
            <Row label="Giờ">{hm(apt.start_time)} – {hm(apt.end_time)}</Row>
            <Row label="Nhân viên">{apt.employee_name || <span className="text-gray-400">Chưa phân công</span>}</Row>
            {staffMode && <Row label="Khách hàng">{apt.customer_name}{apt.customer_phone ? ` · ${apt.customer_phone}` : ''}</Row>}
            {apt.status === 'cancelled' && apt.cancellation_reason && <Row label="Lý do hủy">{apt.cancellation_reason}</Row>}
          </dl>

          {staffMode && (
            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Thông tin thú cưng</p>
              <PetInfoBlock petId={apt.pet_id} />
            </div>
          )}

          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Dịch vụ đã đặt</p>
            <ul className="space-y-1.5">
              {apt.details.map((d) => (
                <li key={d.id} className="flex justify-between gap-3 text-sm">
                  <span className="text-gray-800">{d.service_name} <span className="text-gray-400">· {d.duration_minutes} phút</span></span>
                  <span className="text-gray-900 shrink-0">{formatVND(d.price_at_booking)}</span>
                </li>
              ))}
            </ul>
            <div className="mt-2 pt-2 border-t border-gray-100 flex justify-between text-sm font-semibold">
              <span>Tạm tính</span><span className="text-pink-600">{formatVND(total)}</span>
            </div>
            <p className="text-xs text-gray-400 mt-1">Giá được chốt tại thời điểm đặt lịch.</p>
          </div>

          {apt.customer_notes && (
            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">Ghi chú của khách</p>
              <p className="text-sm text-gray-600 bg-gray-50 rounded-lg px-3 py-2 whitespace-pre-wrap">{apt.customer_notes}</p>
            </div>
          )}

          {apt.care_record && (
            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">Hồ sơ chăm sóc</p>
              <CareRecordCard record={apt.care_record} />
            </div>
          )}

          {staffMode && (
            <div>
              <label htmlFor="staff-notes" className="block text-sm font-medium text-gray-700 mb-1">Ghi chú nội bộ (khách không thấy)</label>
              <textarea id="staff-notes" rows={2} maxLength={1000} value={notes} onChange={(e) => setNotes(e.target.value)}
                readOnly={!canEditNotes} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 read-only:bg-gray-50" />
              {canEditNotes && <button type="button" onClick={saveNotes} disabled={savingNotes || notes.trim() === (apt.staff_notes || '')}
                className="mt-2 px-3 py-1.5 rounded-lg text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 disabled:opacity-50">
                {savingNotes ? 'Đang lưu...' : 'Lưu ghi chú'}
              </button>}
            </div>
          )}

          {/* Phân hệ Hóa đơn & Thanh toán */}
          {apt.status === 'completed' && (
            <div className="pt-2">
              {apt.invoice_id ? (
                <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <span className="text-xs text-gray-500 block">Hóa đơn thanh toán</span>
                    <span className="font-mono font-bold text-gray-900">{apt.invoice_code}</span>
                    <div className="mt-1 flex items-center gap-2">
                      <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold border ${PAYMENT_STATUS_STYLE[apt.invoice_payment_status] || 'bg-gray-100 text-gray-700'}`}>
                        {PAYMENT_STATUS_LABEL[apt.invoice_payment_status] || apt.invoice_payment_status}
                      </span>
                      {apt.invoice_total_amount && (
                        <span className="text-xs text-gray-700 font-semibold">
                          {formatVND(apt.invoice_total_amount)}
                        </span>
                      )}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowInvoiceModal(true)}
                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-medium transition"
                  >
                    Xem chi tiết hóa đơn
                  </button>
                </div>
              ) : staffMode && isStaffUser ? (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-amber-900">Lịch hẹn đã hoàn thành nhưng chưa lập hóa đơn.</p>
                    <p className="text-xs text-amber-700 mt-0.5">Lập hóa đơn để bổ sung phụ phí (nếu có) và thu tiền khách hàng.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowCreateInvoiceModal(true)}
                    className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-medium transition"
                  >
                    + Lập hóa đơn
                  </button>
                </div>
              ) : (
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-3 text-xs text-gray-500">
                  Hóa đơn cho lịch hẹn này đang được nhân viên xử lý.
                </div>
              )}
            </div>
          )}

          {renderActions && <div className="flex flex-wrap justify-end gap-2 pt-2">{renderActions(apt, reload)}</div>}
        </div>
      )}

      {showCreateInvoiceModal && apt && (
        <CreateInvoiceModal
          appointment={apt}
          onClose={() => setShowCreateInvoiceModal(false)}
          onSuccess={() => {
            setShowCreateInvoiceModal(false);
            reload();
          }}
        />
      )}

      {showInvoiceModal && apt?.invoice_id && (
        <InvoiceDetailModal
          invoiceId={apt.invoice_id}
          onClose={() => setShowInvoiceModal(false)}
          onUpdated={reload}
        />
      )}
    </Modal>
  )
}

export default AppointmentDetailModal
